# Hindsight memory layer

**Status: planned.** The results in the README (~20.3 s to ~4.5 s average wait) come from the DQN alone. Memory has not been evaluated yet. The first experiment is a with / without-memory run in SUMO on the same seeds.

## Why

A DQN trained offline is frozen. It does not know this junction's Monday school rush, last week's road closure, or the corner where red lights keep getting jumped. [Hindsight](https://github.com/vectorize-io/hindsight) gives each junction a memory bank that keeps learning.

Hindsight's recall combines semantic, keyword, graph and temporal search, and `reflect` turns stored outcomes into patterns. It is open source and can be self-hosted at the edge. Its published benchmark results are on LongMemEval, a conversational benchmark, not on traffic.

## What each junction remembers

| Operation | Examples |
|---|---|
| **Retain** | Congestion by time and weekday, incidents and closures, decision outcomes (wait time), violation hotspots, human corrections to plate reads |
| **Recall** | Similar past situations at this junction before a decision window |
| **Reflect** | Patterns and an operator handover summary |

The trained DQN stays the same underneath. Memory changes the context around it, so improvement is per junction.

## Setup

```bash
cp .env.example .env                                   # add your LLM key
docker compose -f docker-compose.hindsight.yml up -d   # API :8888, UI :9999
pip install hindsight-client
python examples/hindsight_demo.py
```

The Hindsight server uses an LLM to extract facts when you retain, so it needs `HINDSIGHT_API_LLM_API_KEY`. Other install options (pip server, Kubernetes, managed cloud) are in the [Hindsight docs](https://hindsight.vectorize.io/developer/installation).

## Code

```
hindsight_memory/
  memory.py      JunctionMemory: retain / recall / reflect, one bank per junction
  live_hooks.py  MemoryHooks: two calls to add to the live loop
```

Behaviour you can rely on:

- **Never breaks the pipeline.** If the server is down or the library is missing, memory turns itself off and every call returns an empty result. After an error it pauses for 30 s before trying again.
- **Summaries, not every step.** Retain one sentence per window (default 5 min) or event.
- **Verified data only.** A plate is written to memory only if a human reviewer confirmed it (`reviewed=True`).
- **One bank per junction**, named `traffic-<JUNCTION_ID>`. Hindsight banks are isolated, so junctions never leak into each other.

## Wiring into `run_live_sumorl_violations.py`

Four small additions. Nothing else in the file changes.

```python
# 1. imports (top of file)
from hindsight_memory.live_hooks import MemoryHooks

# 2. in main(), after `viol = ViolationDetector(green_phases)`
mem = MemoryHooks()          # no-op if Hindsight is not running

# 3. in main(), inside decide(), before `return choose_action(...)`
context = mem.on_decision(counts, queued, PHASE_NAMES[sig.phase], now)
# `context` is a list of recalled sentences. Show it to operators, or use
# mem.phase_bias(queued) as an optional hint. The DQN weights are untouched.

# 4. in ViolationDetector.finalize(), right after self.writer.writerow(...)
#    (pass the hooks object in, or call from main after viol.update)
mem.on_violation_recorded(approach="east", vehicle=p["vehicle"],
                          phase_text=p["phase"], plate=plate, reviewed=False)
```

Set `reviewed=True` only from your review step, after a person has checked the plate.

## Tests

```bash
pip install pytest
pytest tests/
```

The tests use a fake client, so no server is needed.

## Risks and mitigations

| Risk | Mitigation |
|---|---|
| Stale or wrong memory | Retain only verified outcomes, decay old entries, separate bank per junction |
| Unproven benefit | Test with vs without memory in SUMO first |
| Privacy of plate data | Unreviewed plates are never retained; use encrypted storage, role-based access and retention limits |
| Server outage | Memory switches off; the DQN runs alone |

## Open questions

- Which recalled signal, if any, should bias the phase choice? `phase_bias` is a deliberately simple keyword hint, not a learned policy.
- How to simulate repeated "Mondays" in SUMO so a memory benefit can be measured.
- Exact shape of the recall response can vary between client versions. `memory.py` handles lists, dicts and objects defensively; check it against your installed `hindsight-client` version.
