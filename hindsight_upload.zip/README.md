# AI Traffic Violation System

**Team Brochacho Labs · GTB4CEC**
Nilesh Kumar, Ayush Pandey, Piyush Kumar, Nitesh Kumar

Adaptive traffic-signal control with a Deep Q-Network (DQN), YOLO camera sensing, automatic red-light violation logging with number-plate reading, and a planned per-junction [Hindsight](https://github.com/vectorize-io/hindsight) memory layer.

## Problem

Fixed-timer signals cannot react to changing traffic. The result is long queues, wasted green time and idle emissions.

## Solution

One pre-installed junction camera does several jobs:

1. **Signal control.** YOLO tracks vehicles, builds a SUMO-RL style observation (phase, density, queue), and a trained DQN picks the next signal phase.
2. **Plate logging.** A plate detector plus `fast-plate-ocr` reads number plates and logs confirmed reads with the approach and signal phase.
3. **Red-light enforcement.** You draw a stop line on the video. A tracked vehicle that crosses it while its approach is red is logged with time, plate and a snapshot.
4. **Memory (planned).** A Hindsight bank per junction retains outcomes and recalls similar past situations before each decision. See [docs/HINDSIGHT.md](docs/HINDSIGHT.md).

## Results

Simulation only (SUMO via TraCI, seeds 100 to 109, same seeds for both controllers).

| Metric | Fixed timer | Trained DQN |
|---|---|---|
| Average wait per vehicle | ~20.3 s | ~4.5 s |
| Reduction | - | ~78% |
| Seeds where DQN wins | - | 10 / 10 |

The Hindsight memory layer is **not** part of these numbers. A with / without-memory comparison on the same seeds is the next experiment.

## Architecture

```mermaid
flowchart LR
    CAM[CCTV camera] --> YOLO[YOLO + tracking]
    YOLO --> STATE[Traffic state<br/>counts, queues]
    STATE --> RECALL[Hindsight recall<br/>planned]
    RECALL --> DQN[DQN policy]
    STATE --> DQN
    DQN --> SIG[Signal phase]
    YOLO --> VIOL[Red-light check<br/>stop line + phase]
    SIG --> VIOL
    CAM --> ANPR[Plate detect + OCR]
    ANPR --> VIOL
    VIOL --> LOG[(violations_log.csv<br/>+ snapshots)]
    LOG --> REVIEW[Human review]
    REVIEW --> RETAIN[Hindsight retain<br/>planned]
    SIG --> RETAIN
```

## Repository layout

| Path | What it is |
|---|---|
| `run_live_sumorl_violations.py` | Live pipeline: YOLO, DQN, plates, red-light check |
| `plates.py` | Stand-alone plate detection and OCR on a video |
| `plates.pt` | Plate detector weights |
| `training/train_dqn.py` | Trains the DQN in SUMO with `sumo-rl` and Stable-Baselines3 |
| `output/dqn_model.zip` | Trained DQN agent |
| `hindsight_memory/` | Per-junction Hindsight memory layer (retain / recall / reflect) |
| `examples/hindsight_demo.py` | Runnable demo of the memory layer |
| `tests/` | Unit tests for the memory layer (no server needed) |
| `docker-compose.hindsight.yml` | Starts a local Hindsight server |
| `docs/HINDSIGHT.md` | How memory works here and how to wire it in |

## Installation

```bash
git clone https://github.com/nileshhww/Ai-traffic-violation-system.git
cd Ai-traffic-violation-system
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Retraining the DQN also needs [SUMO](https://sumo.dlr.de/docs/Installing/index.html) and the `SUMO_HOME` environment variable (see comments in `requirements.txt`).

## Usage

Run the live pipeline on a video, a camera index or an IP camera URL:

```bash
python run_live_sumorl_violations.py --source traffic.mp4 --agent output/dqn_model.zip
python run_live_sumorl_violations.py --source 0 --agent output/dqn_model.zip --no-plates
```

In the video window: press `L` then click two points to set the stop line (saved to `stop_line.json`), `ESC` or `q` to quit.

Outputs, written to the folder you run from:

- `violations_log.csv` and `violations/` (one snapshot per violation)
- `plates_traffic_log.csv` and `crops/`

Plate detection on its own:

```bash
python plates.py
```

Retrain the DQN:

```bash
python training/train_dqn.py
```

## Hindsight memory (planned)

```bash
cp .env.example .env              # add your LLM API key
docker compose -f docker-compose.hindsight.yml up -d
pip install hindsight-client
python examples/hindsight_demo.py
```

Without a server or the client library the memory layer switches itself off and the pipeline behaves exactly as before.

## Privacy and safeguards

- Plate logs, crops and violation snapshots are git-ignored. Never commit them.
- Low-confidence plate reads should go to human review before any penalty.
- Use encrypted storage, role-based access and retention limits in any real deployment.

## Known limitations

- Results are from simulation. A real junction needs calibration against real traffic counts and a pilot.
- `LANE_ZONES`, the stop line and the green phases are camera-specific and need tuning per site.
- Night, rain and occlusion reduce detection and plate-read quality. Fall back to a fixed-timer plan if the camera fails.

## Future work

- With / without-memory evaluation in SUMO on the same seeds
- Reward clipping and tuned epsilon decay; longer training
- Multi-junction coordination and emergency-vehicle priority

## References

- Mnih et al. (2015). Human-level control through deep reinforcement learning. *Nature*, 518.
- Lopez et al. (2018). Microscopic Traffic Simulation using SUMO. IEEE ITSC.
- Wei et al. (2019). A Survey on Traffic Signal Control Methods. arXiv:1904.08117.
- Genders & Razavi (2016). Using a Deep Reinforcement Learning Agent for Traffic Signal Control. arXiv:1611.01142.
- Redmon et al. (2016). You Only Look Once. CVPR.
- [Hindsight](https://github.com/vectorize-io/hindsight) · [docs](https://hindsight.vectorize.io/)

## License

See [LICENSE](LICENSE).
