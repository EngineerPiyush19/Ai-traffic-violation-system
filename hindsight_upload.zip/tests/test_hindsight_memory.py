import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from hindsight_memory import JunctionMemory, MemoryConfig
from hindsight_memory.live_hooks import MemoryHooks


class FakeClient:
    def __init__(self, fail=False):
        self.retained, self.fail = [], fail

    def retain(self, bank_id, content, context=None, timestamp=None):
        if self.fail:
            raise RuntimeError("server down")
        self.retained.append((bank_id, content, context))

    def recall(self, bank_id, query):
        if self.fail:
            raise RuntimeError("server down")
        return [{"text": c} for (_, c, _) in self.retained]

    def reflect(self, bank_id, query):
        return "Mondays surge on the north arm."


def make(client, **kw):
    return JunctionMemory(MemoryConfig(junction_id="j1"), client=client, **kw)


def test_one_bank_per_junction():
    assert make(FakeClient()).bank_id == "traffic-j1"


def test_retain_then_recall_round_trip():
    c = FakeClient()
    m = make(c)
    assert m.retain_event("School surge on the north arm at 08:40")
    hits = m.recall("north arm Monday")
    assert any("north arm" in h for h in hits)


def test_unverified_plate_is_never_retained():
    c = FakeClient()
    m = make(c)
    m.retain_violation("east", "car", "Phase 0", verified=False, plate="DL3CCR8958")
    assert "DL3CCR8958" not in c.retained[0][1]


def test_verified_plate_is_retained():
    c = FakeClient()
    m = make(c)
    m.retain_violation("east", "car", "Phase 0", verified=True, plate="DL3CCR8958")
    assert "DL3CCR8958" in c.retained[0][1]


def test_failure_degrades_to_empty_and_pauses():
    t = [1000.0]
    m = make(FakeClient(fail=True), clock=lambda: t[0])
    assert m.recall("x") == []          # fails, does not raise
    assert m.retain("a", "b") is False  # paused, no second server call
    t[0] += 31
    assert m._active()                  # cooldown over


def test_disabled_memory_is_a_noop():
    m = JunctionMemory(MemoryConfig(enabled=False))
    assert m.retain("a", "b") is False
    assert m.recall("q") == []
    assert m.reflect("q") == ""


def test_hooks_retain_window_and_bias():
    c = FakeClient()
    h = MemoryHooks(make(c), window_sec=10, recall_every_sec=5)
    h._last_retain = 0
    c.retained.append(("traffic-j1", "Monday rush: queue builds on the north arm", "x"))
    h.on_decision({"north": 9}, {"north": 9}, "Phase 0", now=100.0)
    assert h.phase_bias({"north": 9}) == "north"
    assert any("traffic counts" in r[1] for r in c.retained)
