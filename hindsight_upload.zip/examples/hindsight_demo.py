"""Demo: retain a few junction outcomes, recall them, reflect on them.

Needs a running Hindsight server (see docker-compose.hindsight.yml):
    docker compose -f docker-compose.hindsight.yml up -d
    pip install hindsight-client
    python examples/hindsight_demo.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from hindsight_memory import JunctionMemory, MemoryConfig

mem = JunctionMemory(MemoryConfig(junction_id="demo-junction"))
if not mem.enabled:
    sys.exit("Hindsight client not available. Run: pip install hindsight-client")

mem.retain_event("School-gate surge on the north arm around 08:40 every Monday.")
mem.retain_traffic_window(
    counts={"north": 14, "east": 4, "south": 3, "west": 5},
    queued={"north": 9, "east": 1, "south": 0, "west": 1},
    phase="Phase 0 (NS)", avg_wait_s=22.0)
mem.retain_violation("east", "car", "Phase 0 (NS)", verified=False)
mem.retain_plate_correction("DL3CCR8958", "DL3CCR8956")

print("RECALL:")
for line in mem.recall_similar_situation("Monday", "08:40", {"north": 9, "east": 1}):
    print(" -", line)

print("\nHANDOVER SUMMARY:")
print(mem.handover_summary() or "(no answer; is the server running?)")
