"""Per-junction memory on top of Hindsight (https://github.com/vectorize-io/hindsight).

One Hindsight *bank* per junction. Three operations:

  retain   store a verified outcome (a congestion window, a violation, a reviewer fix)
  recall   fetch similar past situations before a decision window
  reflect  ask for patterns ("what happens here on Mondays?")

Design rules
------------
* Never break the live pipeline. If the server is down, the client library is not
  installed, or a call fails, every method returns an empty result and the junction
  runs on the DQN alone.
* Retain summaries, not every step. Hindsight uses an LLM to extract facts on retain,
  so write one short sentence per window or event, not one per simulation step.
* Retain only verified outcomes. Plate reads go in only after a human reviewer
  confirms or corrects them.
* Memory is context for the policy and for operators. It does not replace the DQN.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

log = logging.getLogger("hindsight_memory")


@dataclass
class MemoryConfig:
    junction_id: str = field(default_factory=lambda: os.getenv("JUNCTION_ID", "junction-001"))
    base_url: str = field(default_factory=lambda: os.getenv("HINDSIGHT_URL", "http://localhost:8888"))
    enabled: bool = True
    # Stop calling the server for this many seconds after a failure.
    cooldown_after_error_sec: float = 30.0

    @property
    def bank_id(self) -> str:
        return f"traffic-{self.junction_id}"


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _to_text(item: Any) -> str:
    """Best-effort conversion of one recall hit to a string (client response shapes vary)."""
    if isinstance(item, str):
        return item
    if isinstance(item, dict):
        for key in ("text", "content", "memory", "fact"):
            if item.get(key):
                return str(item[key])
        return str(item)
    for attr in ("text", "content", "memory", "fact"):
        value = getattr(item, attr, None)
        if value:
            return str(value)
    return str(item)


def _hits(response: Any) -> list:
    """Pull the list of hits out of whatever recall() returned."""
    if response is None:
        return []
    if isinstance(response, (list, tuple)):
        return list(response)
    if isinstance(response, dict):
        for key in ("results", "memories", "items"):
            if isinstance(response.get(key), (list, tuple)):
                return list(response[key])
        return []
    for attr in ("results", "memories", "items"):
        value = getattr(response, attr, None)
        if isinstance(value, (list, tuple)):
            return list(value)
    return []


class JunctionMemory:
    """Thin, failure-tolerant wrapper around the Hindsight Python client."""

    def __init__(self, config: Optional[MemoryConfig] = None, client: Any = None,
                 clock=None):
        self.config = config or MemoryConfig()
        self._clock = clock or __import__("time").time
        self._client = client
        self._disabled_until = 0.0
        self.enabled = self.config.enabled

        if self.enabled and self._client is None:
            try:
                from hindsight_client import Hindsight  # pip install hindsight-client
                self._client = Hindsight(base_url=self.config.base_url)
            except Exception as exc:  # library missing or bad URL
                log.warning("Hindsight unavailable (%s). Memory is OFF.", exc)
                self.enabled = False

    # ------------------------------------------------------------------ plumbing
    @property
    def bank_id(self) -> str:
        return self.config.bank_id

    def _active(self) -> bool:
        return self.enabled and self._clock() >= self._disabled_until

    def _guard(self, fn, default):
        if not self._active():
            return default
        try:
            return fn()
        except Exception as exc:
            self._disabled_until = self._clock() + self.config.cooldown_after_error_sec
            log.warning("Hindsight call failed (%s). Pausing memory for %.0fs.",
                        exc, self.config.cooldown_after_error_sec)
            return default

    # ------------------------------------------------------------------ retain
    def retain(self, content: str, context: str, timestamp: Optional[str] = None) -> bool:
        """Store one sentence. Returns True if the call went through."""
        def _call():
            self._client.retain(bank_id=self.bank_id, content=content,
                                context=context, timestamp=timestamp or _now_iso())
            return True
        return self._guard(_call, False)

    def retain_traffic_window(self, counts: dict, queued: dict, phase: str,
                              avg_wait_s: Optional[float] = None) -> bool:
        """One summary per decision window (not per frame)."""
        worst = max(queued, key=queued.get) if queued else "unknown"
        text = (f"At {junction_label(self.config)}, traffic counts were {counts} and queued "
                f"vehicles were {queued} while the signal showed {phase}. "
                f"The longest queue was on the {worst} arm.")
        if avg_wait_s is not None:
            text += f" Average wait over the window was {avg_wait_s:.1f} seconds."
        return self.retain(text, context="traffic window outcome")

    def retain_violation(self, approach: str, vehicle: str, phase: str,
                         verified: bool, plate: Optional[str] = None) -> bool:
        """Retain a red-light violation. Plates are included only once a human verified them."""
        text = (f"A {vehicle} crossed the stop line on red on the {approach} approach "
                f"during {phase} at {junction_label(self.config)}.")
        if verified and plate:
            text += f" Reviewer-verified plate: {plate}."
        return self.retain(text, context="red-light violation hotspot")

    def retain_plate_correction(self, ocr_read: str, corrected: str) -> bool:
        """A reviewer fixed an OCR read. Used to calibrate plate-read confidence."""
        text = f"The plate reader output '{ocr_read}' and a human reviewer corrected it to '{corrected}'."
        return self.retain(text, context="plate read correction")

    def retain_event(self, description: str) -> bool:
        """Closures, school events, roadworks, weather."""
        return self.retain(f"At {junction_label(self.config)}: {description}", context="incident or event")

    # ------------------------------------------------------------------ recall
    def recall(self, query: str, limit: int = 5) -> list[str]:
        """Return up to `limit` past situations as plain strings. Empty list on any problem."""
        def _call():
            response = self._client.recall(bank_id=self.bank_id, query=query)
            return [_to_text(h) for h in _hits(response)][:limit]
        return self._guard(_call, [])

    def recall_similar_situation(self, weekday: str, hhmm: str, queued: dict,
                                 limit: int = 5) -> list[str]:
        worst = max(queued, key=queued.get) if queued else "any"
        query = (f"What traffic happened at this junction on {weekday} around {hhmm}, "
                 f"especially queues on the {worst} arm, and what signal choice worked?")
        return self.recall(query, limit=limit)

    # ------------------------------------------------------------------ reflect
    def reflect(self, question: str) -> str:
        """Pattern-level answer, e.g. for an operator handover summary."""
        def _call():
            response = self._client.reflect(bank_id=self.bank_id, query=question)
            if isinstance(response, str):
                return response
            for attr in ("text", "answer", "response", "content"):
                value = getattr(response, attr, None) or (
                    response.get(attr) if isinstance(response, dict) else None)
                if value:
                    return str(value)
            return str(response)
        return self._guard(_call, "")

    def handover_summary(self) -> str:
        return self.reflect(
            "Give an operator a short handover summary: recurring rush hours, repeat "
            "red-light spots, closures, and plate-read problems at this junction.")


def junction_label(config: MemoryConfig) -> str:
    return f"junction {config.junction_id}"
