"""Glue for run_live_sumorl_violations.py.

Keeps the live loop change tiny: build one MemoryHooks object, call `on_decision`
inside the signal decision callback and `on_violation_recorded` when a violation row
is written. Both are cheap no-ops when memory is off.

The recalled text is passed to the policy only as an *optional bias* (see
`phase_bias`). The trained DQN weights are never changed.
"""

from __future__ import annotations

import time
from typing import Optional

from .memory import JunctionMemory


class MemoryHooks:
    def __init__(self, memory: Optional[JunctionMemory] = None,
                 window_sec: float = 300.0, recall_every_sec: float = 60.0):
        self.memory = memory or JunctionMemory()
        self.window_sec = window_sec
        self.recall_every_sec = recall_every_sec
        self._last_retain = time.time()
        self._last_recall = 0.0
        self.last_context: list[str] = []

    def on_decision(self, counts: dict, queued: dict, phase_text: str, now: float) -> list[str]:
        """Call once per DQN decision. Returns recalled context (may be empty)."""
        if now - self._last_recall >= self.recall_every_sec:
            self._last_recall = now
            lt = time.localtime(now)
            self.last_context = self.memory.recall_similar_situation(
                weekday=time.strftime("%A", lt), hhmm=time.strftime("%H:%M", lt), queued=queued)
        if now - self._last_retain >= self.window_sec:
            self._last_retain = now
            self.memory.retain_traffic_window(counts, queued, phase_text)
        return self.last_context

    def on_violation_recorded(self, approach: str, vehicle: str, phase_text: str,
                              plate: str, reviewed: bool = False) -> None:
        """Call when a violation row is finalised. Pass reviewed=True only after human review."""
        self.memory.retain_violation(approach, vehicle, phase_text, verified=reviewed,
                                     plate=plate if reviewed else None)

    def phase_bias(self, queued: dict) -> Optional[str]:
        """Return the arm memory expects to surge, if recalled text names one, else None.

        Deliberately simple keyword matching: an operator-visible hint, not a learned policy.
        """
        text = " ".join(self.last_context).lower()
        if not text:
            return None
        for arm in ("north", "south", "east", "west"):
            if f"{arm} arm" in text and ("surge" in text or "queue" in text or "rush" in text):
                return arm
        return None
